# m23.py
# マイコン宇宙講座
# 2-3 ユリウス暦とグレゴリオ暦の境目確認プログラム
import lib

D = [1, 2, 3, 4, 15, 16, 17, 18, 19, 20, 21, 22, 23, 24, 25, 26, 27, 28, 29, 30, 31]

yy = 1582
mm = 10

print()
print('        年 月 日       JD')

for i in range(len(D)):
    dd = D[i]
    jd = lib.julian(yy, mm, dd)
    print('      %4d %2d %2d %12.1f' % (yy, mm, dd, jd))

print()
