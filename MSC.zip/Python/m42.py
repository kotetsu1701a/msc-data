# m42.py
# マイコン宇宙講座
# 4-2 ５°おきの地理緯度、地心緯度、地心距離計算プログラム
import lib


print()
print('     地理緯度     地心緯度    その差    地心距離')
print('     -------------------------------------------')
print('        。           。        。　　　 　　　Km')
for i in range(0, 90, 5):
    la = i / lib.K[3]
    r1 = la
    r2 = 0
    r3 = lib.geocentric_latitude(r1, r2)
    fi = r3
    r1 = la
    r2 = lib.geocentric_distance(r1)
    r0 = r2
    print('     %7.3f      %7.3f     %5.3f     %8.2f' % (la * lib.K[3], fi * lib.K[3], (la - fi) * lib.K[3], r0))

print('     -------------------------------------------')
print()
