# m51.py
# マイコン宇宙講座
# 月の位置計算プログラム
import lib
import math


M2PI = 2.0 * math.pi

print()
std = input('DATE AND TIME(JST) ? ')
dy, dt = std.split(',')
dy = float(dy)
dt = float(dt)

jd, yy, mm, dd, hh, ms, ss = lib.mjd(dy, dt)

iv = input('INTERVAL(UNIT OF HOUR) ? ')
iv = float(iv)

ii = 0
yz = 0
md = 0

print()
print('        Date (JST)              R.A.   (Date)   Decl.          Distance')
print('      -----------------------------------------------------------------')
print('           年 月 日  時 分        h   m         。   ,              Km')

while ii < 32:
    ta = (jd - 15019.5) / 36525.0
    a, b, c, d, e, g, j, l, m, n, v, w = lib.argument(ta)
    mx, my, mz = lib.moon(ta, a, b, d, e, n, g, w)

    r0 = c
    r1 = mx
    r2 = my
    r3 = mz

    ra, dc, dl = lib.positions(r0, r1, r2, r3)

    if ra < 0:
        ra = ra + M2PI

    ra = ra * lib.K[3] / 15.0
    dc = dc * lib.K[3]
    dl = 6378.16 * dl
    jd = jd + 0.375

    yy, mm, dd = lib.jdate(jd, lib.T)

    jd = jd - 0.375
    hh = 24.0 * (dd - int(dd))
    dd = int(dd)
    ms = 60.0 * (hh - int(hh))
    hh = int(hh)
    if int(ms + 0.1) == 60:
        hh = hh + 1
        ms = 0

    rh = int(ra)
    rm = 60.0 * (ra - rh)
    sg = lib.sgn(dc)
    dc = abs(dc)
    dh = int(dc)
    dm = 60.0 * (dc - dh)
    s = '+'
    if sg < 0:
        s = '-'

    if yy != yz:
        print('       %4d %2d %2d  %2d %2d        %2d  %5.2f    %1s%2d  %5.1f         %6.0f' % (yy, mm, dd, hh, ms, rh, rm, s, dh, dm, dl))
    else:
        if mm != md:
            print('            %2d %2d  %2d %2d        %2d  %05.2f    %1s%2d  %5.1f         %6.0f' % (mm, dd, hh, ms, rh, rm, s, dh, dm, dl))
        else:
            print('               %2d  %2d %2d        %2d  %5.2f    %1s%2d  %5.1f         %6.0f' % (dd, hh, ms, rh, rm, s, dh, dm, dl))

    yz = yy
    md = mm
    ii = ii + 1
    if ii < 32:
        jd = jd + iv / 24.0
    else:
        break

print('      -----------------------------------------------------------------')
print()
