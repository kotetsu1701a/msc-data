# m312.py
# マイコン宇宙講座
# 3-12 太陽と惑星の出没時刻計算プログラム
import math
import lib


lg = 139.745 / lib.K[3]
la = 35.654 / lib.K[3]
obs = '東京'

lib.PL[3] = 'Sun'

x = [[0 for i in range(10)] for j in range(4)]
f = [0, 0, 0, 0]
q = [0, 0, 0, 0]
ra = [0 for i in range(10)]
dc = [0 for i in range(10)]

print('\n')
std = input('DATE AND TIME(JST) ? ')
dy, dt = std.split(',')
dy = float(dy)
dt = float(dt)

jd, yy, mm, dd, hh, ms, ss = lib.mjd(dy, dt)

iv = input('計算の間隔 ? ')
pn = input('惑星のナンバー ? ')
iv = float(iv)
pn = int(pn)

ja = jd + 365

print()
print(' %-7s(東経 %7.3f 北緯 %6.3f) での　%-7s の出没時刻 (JST)' % (obs, lg * lib.K[3], la * lib.K[3], lib.PL[pn]))
print()
print(' Date                         出               没　　    　　　方位')
print(' --------------------------------------------------------(北からの角度)---')
print('      年   月   日          時   分          時   分             。')

ha = 0
hd = 0
sg = 0
yz = 0
dz = 0
ta1 = 0
td1 = 0
ta = 0
td = 0
al = 0
mz = 0

# 出没時刻の計算
# L300:
while True:
    ty = yy + (mm - 1) / 12 + dd / 365
    if hd == 0:
        ha = ta1
    if hd == 1:
        ha = td1

    # L400:
    while True:
        sg = 0
        if ha > 15:
            sg = -1

        t1 = jd + sg + ha / 24.0 - 33281.92334
        t1 = t1 * (2.737909288e-5 + 1.260132857e-17 * t1)
        t2 = t1 * t1

        # L440:
        while True:
            # EARTH
            e, m, p, n, i, a, rd = lib.mean_elements(3, t1, t2)
            pe = p
            nd = n
            ic = i
            f, q = lib.eph_const(pe, nd, ic, lib.K)

            ec = e
            mo = m / (2.0 * math.pi)
            mo = 2.0 * math.pi * (mo - int(mo))

            ss, cc, ff = lib.kepler(mo, ec)

            b = a * math.sqrt(1.0 - e * e)
            for n in range(1, 4):
                x[n][3] = -1 * (ff * a * f[n] + ss * b * q[n])

            # 惑星の平均軌道要素の計算
            if pn != 3:
                e, m, p, n, i, a, rd = lib.mean_elements(pn, t1, t2)
                pe = p
                nd = n
                ic = i
                f, q = lib.eph_const(pe, nd, ic, lib.K)

                ec = e
                mo = m / (2.0 * math.pi)
                mo = 2.0 * math.pi * (mo - int(mo))

                ss, cc, ff = lib.kepler(mo, ec)

                b = a * math.sqrt(1.0 - e * e)
                for n in range(1, 4):
                    f[n] = a * f[n]
                    q[n] = b * q[n]

                # 惑星の座標の計算
                for n in range(1, 4):
                    x[n][pn] = ff * f[n] + ss * q[n]

                for n in range(1, 4):
                    x[n][pn] = x[n][pn] + x[n][3]

            # L900:
            # 惑星の赤経・赤緯の計算
            cc = x[1][pn]
            ss = x[2][pn]

            tt = lib.quadrant(ss, cc)

            ra[pn] = tt
            cc = x[1][pn] / math.cos(ra[pn])
            ss = x[3][pn]
            dc[pn] = math.atan(ss / cc)

            r1 = ra[pn]
            d1 = dc[pn]

            rax, dcx = lib.precession(r1, d1, ty, 0, 0, lib.K)

            ra[pn] = rax
            dc[pn] = dcx
            ds = math.sqrt(x[1][pn]**2 + x[2][pn]**2 + x[3][pn]**2)
            rdx = rd
            result = lib.appear(jd, lg, la, rax, dcx, ds, rdx, sg, hd, lib.K)

            flags_0 = False
            flags_1 = False
            flags_2 = False

            if hd == 1:
                td = result[0]
                al = result[1]
                if abs(td - ha) < 2.0e-3:
                    flags_2 = True
                else:
                    ha = td
                    continue
            else:
                if hd == 0:
                    # 出
                    ta = result[0]
                    if abs(ta - ha) > 2.0e-3:
                        ha = ta
                        flags_1 = True
                    else:
                        if hd == 0:
                            hd = 1
                            ha = ta
                            flags_0 = True

            if flags_0 or flags_1 or flags_2:
                break
        # end of L440

        if flags_0 or flags_2:
            break
    # end of L400

    if flags_0:
        continue

    if flags_2:
        ta1 = ta
        ta = ta + 9
        if ta > 24:
            ta = ta - 24

        td1 = td
        td = td + 9
        if td > 24:
            td = td - 24

        h1 = int(ta)
        m1 = 60.0 * (ta - h1)
        h2 = int(td)
        m2 = 60.0 * (td - h2)
        al = al * lib.K[3]

        yy, mm, dd = lib.jdate(jd, lib.T)

        sfmt = '              %2d          %2d   %4.1f        %2d   %4.1f         %6.1f' % (dd, h1, m1, h2, m2, al)
        if yy != yz:
            sfmt = '  %4d   %2d   %2d          %2d   %4.1f        %2d   %4.1f         %6.1f' % (yy, mm, dd, h1, m1, h2, m2, al)
        if mm != mz:
            sfmt = '         %2d   %2d          %2d   %4.1f        %2d   %4.1f         %6.1f' % (mm, dd, h1, m1, h2, m2, al)
        print(sfmt)
        yz = yy
        mz = mm
        if jd < ja:
            jd += iv
            ha = 0
            hd = 0
        else:
            break
# end of L300
print(' -------------------------------------------------------------------------')
print()
