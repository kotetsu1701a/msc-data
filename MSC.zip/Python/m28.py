# m28.py
# マイコン宇宙講座
# 2-8 離心近点離角計算プログラム
import lib


print()
mo = float(input('Mo ? ')) / lib.K[3]
ec = float(input('E ? '))

print()
print('INPUT Mo = %9.5f' % (mo * lib.K[3]))
print(('INPUT e  =   %9.7f' % ec))
print()
print('          A1          A2')

ss, cc, ff, a1 = lib.kepler(mo, ec)

print()
print('E = %9.5f' % (a1 * lib.K[3]))
print()
