# m24.py
# マイコン宇宙講座
# 2-4 万年カレンダープログラム
import lib


print()
std = input('DATE ? ')
dy = float(std)
dt = 90000.0

jd, yy, mm, dd, hh, ms, ss = lib.mjd(dy, dt)

print()
print('%4d 年%2d 月' % (yy, mm))
print(lib.tab(7) + ' SU MO TU WE TH FR SA')

f = mm
i = 0
while i < 31:
    n = (jd - 4.0) / 7.0
    no = 7 * (n - int(n))
    no = int(no + 0.1)

    yy, mm, dd = lib.jdate(jd, lib.T)

    if mm != f:
        break

    if no == 0:
        print(lib.tab(7), end='')

    # その月の1日が日曜日だと、初週の日の表示がずれるためにif文を追加
    if (no == 0) and (dd == 1):
        print('%3d' % dd, end='')
    else:
        if i == 0:
            print(lib.tab(no * 3 + 7), end='')

        if no == 6:
            print('%3d' % dd)
        else:
            print('%3d' % dd, end='')

    i += 1
    jd += 1

print()
