# 日食シミュレーションで作成された画像を表示する
#
# 要インストール
# sudo apt install python3-pil.imagetk
#
from PIL import Image, ImageDraw, ImageFont
from tkinter.constants import SOLID
from tkinter import messagebox as msgbox
import tkinter as tk
import glob
import time


def display_eclipse():
    global count
    drawing_image_file(files[count])


def display_eclipse_prev():
    global count
    count -= 1
    if count < 0:
        count = 0
    drawing_image_file(files[count])


def display_eclipse_next():
    global count, file_number
    count += 1
    if count > file_number - 1:
        count = file_number - 1
    drawing_image_file(files[count])

    
def drawing_image_file(picture):
    global photo

    # 画像の表示
    photo = tk.PhotoImage(file=picture)
    canvas.create_image(1, 1, image=photo, anchor=tk.NW)


# メイン
root = tk.Tk()
root.resizable(False, False)
root.geometry('640x440')
root.title('マイコン宇宙講座 - 日食シミュレーションプログラム')

# キャンバスの作成
canvas = tk.Canvas(root, width=640, height=400, bg='black')
canvas.pack(anchor=tk.NW)

# imagesフォルダ内にある画像ファイルを取得する
files = sorted(glob.glob('./images/eclipse/*.png'))

# カウンターとファイルの数を取得
count = 0
file_number = len(files)

# 最初の画像を表示
display_eclipse()

# 前の画像を表示
button = tk.Button(root, text='Prev', width=6, relief=SOLID, cursor='hand1', command=display_eclipse_prev)
button.place(x=8, y=407)

# 次の画像を表示
button = tk.Button(root, text='Next', width=6, relief=SOLID, cursor='hand1', command=display_eclipse_next)
button.place(x=86, y=407)

# 閉じる
button = tk.Button(root, text='閉じる', width=6, relief=SOLID, cursor='hand1', command=root.destroy)
button.place(x=558, y=407)

root.mainloop()
