# m25.py
# マイコン宇宙講座
# 2-5 南中している天体の赤経計算プログラム
import lib


lg = 139.5315556 / lib.K[3]
obs = '東京'

print()
std = input('DATE AND TIME(JST) ? ')
dy, dt = std.split(',')
dy = float(dy)
dt = float(dt)

jd, yy, mm, dd, hh, ms, ss = lib.mjd(dy, dt)

r1 = jd
r2 = lg

s1 = lib.siderealtime_date(r1, r2)

s1 *= lib.K[3] / 15.0
rh = int(s1)
rs = 60.0 * (s1 - rh)
rm = int(rs)
rs = 60.0 * (rs - rm)

print()
print('%4d 年 %2d 月 %2d 日 %2d 時 %2d 分 %3.1f 秒(JST)' % (yy, mm, dd, hh, ms, ss))
print(obs + 'の恒星時')
print()
print('     %2dh %2dm %5.3fds(DATE)' % (rh, rm, rs))
print()

s1 = lib.siderealtime_1950(r1, r2)

s1 *= lib.K[3] / 15.0
rh = int(s1)
rs = 60.0 * (s1 - rh)
rm = int(rs)
rs = 60.0 * (rs - rm)

print('     %2dh %2dm %5.3fds(1950)' % (rh, rm, rs))
print()
