# m53.py
# マイコン宇宙講座
# 5-3 月の出入り時刻計算プログラム
import lib


lg = 139.745 / lib.K[3]
la = 35.654 / lib.K[3]
obs = 'Tokyo'

std = input('\nDATE AND TIME(JST) ? ')
dy, dt = std.split(',')
dy = float(dy)
dt = float(dt)

jd, yy, mm, dd, hh, ms, ss = lib.mjd(dy, dt)

ia = 0
ha = 0
hd = 0
sg = 0
ii = 0
ta = 0
td = 0
ta1 = 0
td1 = 0

print()
print('%-s (経度:%5.3f 緯度:%3.3f)' % (obs, lg * lib.K[3], la * lib.K[3]))
print('          (JST)          月の出          月の入り        方位')
print('-----------------------------------------------------(北からの角度)-')
print('       年  月  日         時  分           時  分            。')

# 出没時刻の近似
while True:
    if hd == 0:
        ha = ta1
    if hd == 1:
        ha = td1

    # L400:
    while True:
        sg = 0
        if ha > 15:
            sg = -1

        t0 = (jd - 15019.5 + sg + ha / 24.0) / 36525.0

        a, b, c, d, e, g, j, l, m, n, v, w = lib.argument(t0)
        mx, my, mz = lib.moon(t0, a, b, d, e, n, g, w)

        r0 = c
        r1 = mx
        r2 = my
        r3 = mz

        ra, dc, dl = lib.positions(r0, r1, r2, r3)

        ds = dl / 23454.706
        rd = 0
        result = lib.appear(jd, lg, la, ra, dc, ds, rd, sg, hd, lib.K)

        flags = False
        while True:
            if hd == 1:
                break
            ta = result[0]
            if abs(ta - ha) < 2.0e-3:
                break
            if ia == 5:
                break
            ha = ta
            ia = ia + 1
            flags = True

        if flags:
            continue        # 400

        flags = False
        td = result[0]
        al = result[1]
        if hd == 0:
            hd = 1
            id = 0
            ha = 0
            flags = True

        if flags:
            break

        if abs(td - ha) < 2.0e-3:
            break
        if id == 5:
            break
        ha = td
        id = id + 1
        continue        # 400

    if flags:
        continue        # 300

    # L570:
    ta1 = ta
    ta = ta + 9
    if ta > 24:
        ta = ta - 24
    td1 = td
    td = td + 9
    if td > 24:
        td = td - 24

    h1 = int(ta)
    m1 = 60.0 * (ta - h1)
    h2 = int(td)
    m2 = 60.0 * (td - h2)
    al = al * lib.K[3]
    yy, mm, dd = lib.jdate(jd, lib.T)

    sfmt = '  %4d   %2d   %2d        %2d   %4.1f        %2d   %4.1f       %6.1f' % (yy, mm, dd, h1, m1, h2, m2, al)
    if ia == 5:
        sfmt = '  %4d   %2d   %2d        --   --.-        %2d   %4.1f       %6.1f' % (yy, mm, dd, h2, m2, al)
    if id == 5:
        sfmt = '  %4d   %2d   %2d        %2d   %4.1f        --   --.-       %6.1f' % (yy, mm, dd, h1, m1, al)

    print(sfmt)

    ii = ii + 1
    if ii < 32:
        jd = jd + 1.0
        ia = 0
        id = 0
        ha = 0
        hd = 0
    else:
        break

print('--------------------------------------------------------------------')
print()
