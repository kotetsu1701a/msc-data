# m26.py
# マイコン宇宙講座
# 2-6 恒星の歳差計算プログラム
import math
import lib


print()
yy = int(input('計算を始めたい年 ? '))
ra = float(input('恒星の赤経 ? ')) / lib.K[3]
dc = float(input('恒星の赤緯 ? ')) / lib.K[3]
pr = float(input('赤経方向の固有運動量 ? '))
pd = float(input('赤緯方向の固有運動量 ? '))
la = float(input('緯度 ? ')) / lib.K[3]

print()
print('  YEAR   R.A.     DECL.   DIRECTION(N to E)')
print('             。       。         。')

r1 = ra
d1 = dc
for y in range(yy, 1700, 100):
    ty = y + 0.25
    ra, dc = lib.precession(r1, d1, ty, pr, pd, lib.K)

    cc = math.sin(dc) / math.cos(la)
    ss = math.sqrt(1.0 - cc * cc)
    al = math.atan(ss / cc)
    if al < 0:
        al += math.pi
    al *= lib.K[3]
    ra *= lib.K[3]
    dc *= lib.K[3]

    print('  %4d   %7.2f  %7.2f     %6.2f' % (ty, ra, dc, al))

print()
