# m56.py
# マイコン宇宙講座
# 月の高度・方位計算プログラム
import math
import lib

M2PI = 2.0 * math.pi

lg = 139.745 / lib.K[3]
la = 35.654 / lib.K[3]
obs = 'Tokyo'

print()
std = input('DATE AND TIME(JST) ? ')
dy, dt = std.split(',')
dy = float(dy)
dt = float(dt)

jd, yy, mm, dd, hh, ms, ss = lib.mjd(dy, dt)

iv = input('INTERVAL(UNIT OF MINUTE) ? ')
iv = float(iv)

ii = 0
yz = 0
mt = 0

print()
print('%-s (経度:%5.3f 緯度:%3.3f)' % (obs, lg * lib.K[3], la * lib.K[3]))
print('  Date (JST)                R.A.      Decl.         方位        高度      距離')
print('--------------------------------------------------------------------------------')
print('     年  月  日  時  分      h  m       。 ,           。         。         Km')

while ii < 32:
    t0 = (jd - 15019.5) / 36525.0

    a, b, c, d, e, g, j, l, m, n, v, w = lib.argument(t0)
    mx, my, mz = lib.moon(t0, a, b, d, e, n, g, w)

    r0 = c
    r1 = mx
    r2 = my
    r3 = mz

    ra, dc, dl = lib.positions(r0, r1, r2, r3)

    dl1 = dl
    if ra < 0:
        ra = ra + M2PI
    r1 = la

    r2 = lib.geocentric_distance(r1)

    r0 = r2 / 6378.16
    r1 = la
    r2 = 0

    r3 = lib.geocentric_latitude(r1, r2)

    fi = r3
    r1 = jd
    r2 = lg

    r3 = lib.siderealtime_date(r1, r2)

    s1 = r3
    x0 = r0 * math.cos(fi) * math.cos(s1)
    y0 = r0 * math.cos(fi) * math.sin(s1)
    z0 = r0 * math.sin(fi)

    xx = dl * math.cos(dc) * math.cos(ra)
    yy = dl * math.cos(dc) * math.sin(ra)
    zz = dl * math.sin(dc)

    x = xx - x0
    y = yy - y0
    z = zz - z0

    dl2 = math.sqrt(x * x + y * y + z * z)
    ss = y
    cc = x

    tt = lib.quadrant(ss, cc)

    ra = tt
    dc = math.atan(z / (y / math.sin(ra)))

    al, hi = lib.altitude_direction(jd, lg, la, ra, dc)

    # MJD to YY-MM-DD
    jd = jd + 0.375

    yy, mm, dd = lib.jdate(jd, lib.T)

    jd = jd - 0.375
    hh = 24.0 * (dd - int(dd))
    dd = int(dd)
    ms = 60.0 * (hh - int(hh))
    hh = int(hh)
    ms = int(ms + 0.1)

    if ms == 60:
        hh = hh + 1
        ms = 0

    while True:
        if hi < -0.17:
            break
        # Print Position
        if ra < 0:
            ra = ra + M2PI
        if ra > M2PI:
            ra = ra - M2PI

        ra = ra * lib.K[3] / 15.0
        dc = dc * lib.K[3]
        dl2 = 6378.16 * dl2

        rh = int(ra)
        rm = 60.0 * (ra - rh)
        sg = lib.sgn(dc)
        dc = abs(dc)
        dh = int(dc)
        dm = 60.0 * (dc - dh)

        s1 = '+'
        if sg < 0:
            s1 = '-'

        hi = hi * lib.K[3]
        al = al * lib.K[3]

        if yy != yz:
            sfmt = ' %4d  %2d  %2d  %2d  %2d      %2d %5.2f  %1s%2d %4.1f       %5.1f       %4.1f     %6d' % (yy, mm, dd, hh, ms, rh, rm, s1, dh, dm, al, hi, dl2)
        else:
            if mm != mt:
                sfmt = '       %2d  %2d  %2d  %2d      %2d %5.2f  %1s%2d %4.1f       %5.1f       %4.1f     %6d' % (mm, dd, hh, ms, rh, rm, s1, dh, dm, al, hi, dl2)
            else:
                sfmt = '           %2d  %2d  %2d      %2d %5.2f  %1s%2d %4.1f       %5.1f       %4.1f     %6d' % (dd, hh, ms, rh, rm, s1, dh, dm, al, hi, dl2)
        print(sfmt)
        yz = yy
        mt = mm
        break

    ii = ii + 1
    if ii < 32:
        jd = jd + iv / 1440

print('--------------------------------------------------------------------------------')
print()
