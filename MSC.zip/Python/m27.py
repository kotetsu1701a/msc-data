# m27.py
# マイコン宇宙講座
# 2-7 惑星の軌道要素計算プログラム
import math
import lib


print()
std = input('DATE AND TIME(JST) ? ')
dy, dt = std.split(',')
dy = float(dy)
dt = float(dt)

jd, yy, mm, dd, hh, ms, ss = lib.mjd(dy, dt)

t1 = jd - 33281.92334
t1 = t1 * (2.737909288e-5 + 1.260132857e-17 * t1)
t2 = t1 * t1

print()
print('DATE = %4d %2d %2d   TIME = %2d h %2d m %2.1f s (JST)' % (yy, mm, dd, hh, ms, ss))
print('      MJD = %10.4f ET' % (lib.fnb(jd)))
print()
print('PLANET     Mo         Peri.      Node        Inc.     e')
print('             。         。         。         。')

for j in range(1, 10):
    pn = j
    e, m, p, n, i, a, rd = lib.mean_elements(pn, t1, t2)

    m = 2.0 * math.pi * (m / (2.0 * math.pi) - int(m / (2.0 * math.pi)))
    m *= lib.K[3]
    p *= lib.K[3]
    if p < 0:
        p += 360.0
    n *= lib.K[3]
    i *= lib.K[3]

    print('%-7s  %10.5f %10.5f %10.5f %10.5f %10.7f' % (lib.PL[pn], m, p, n, i, e))

print()
