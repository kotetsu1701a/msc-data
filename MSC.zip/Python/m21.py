# m21.py
# マイコン宇宙講座
# 2-1 JST<->MJD変換プログラム
import lib


print()
std = input('DATE AND TIME(JST) ? ')
dy, dt = std.split(',')
dy = float(dy)
dt = float(dt)

jd, yy, mm, dd, hh, ms, ss = lib.mjd(dy, dt)
dtime = hh / 24.0 + ms / 1440.0 + ss / 86400.0

print()
print('   INPUT DATE = %4d %2d %7.5f UT' % (yy, mm, dd + dtime - 0.375))
print('         MJD  = %13.5f UT' % jd)
print()

yy, mm, dd = lib.jdate(jd, lib.T)
print('  RETURN DATE = %4d %2d %7.5f UT' % (yy, mm, dd))

jd = lib.julian(yy, mm, dd) - 2400000.5
print('         MJD  = %13.5f UT' % jd)
print()
