# m41.py
# マイコン宇宙講座
# 4-1 地理緯度を入力して地心緯度・地心距離を求めるプログラム
import lib


print('\n')
na = input('地名 ? ')
la = input('地理緯度 ? ')
la = float(la)

la /= lib.K[3]
r1 = la
r2 = 0
r3 = lib.geocentric_latitude(r1, r2)
f1 = r3

r1 = la
r2 = lib.geocentric_distance(r1)
r0 = r2

# サブルーチンgeography_latitudeによる再計算
r1 = f1
r2 = lib.geography_latitude(r1)
lb = r1
rr = r2
print(rr)
print()
print('      地理緯度 = %7.3f' % (la * lib.K[3]))
print('      地心緯度 = %7.3f' % (f1 * lib.K[3]))
print('      地心距離 = %7.2f Km' % (r0))
print()
print('=== サブルーチン地理緯度による再計算 ===')
print()
print('      地理緯度 = %7.3f' % (lb * lib.K[3]))
print('      地心距離 = %7.2f Km' % (rr))
print()
