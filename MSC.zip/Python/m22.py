# m22.py
# マイコン宇宙講座
# 2-2 年月日算出プログラム
import lib


print()
std = input('DATE AND TIME(JST) ? ')
dy, dt = std.split(',')
dy = float(dy)
dt = float(dt)

jd, yy, mm, dd, hh, ms, ss = lib.mjd(dy, dt)

# UT表示するための処理
yy, mm, dd = lib.jdate(jd, lib.T)

print()
print('   INPUT DATE = %4d %2d %7.5f UT' % (yy, mm, dd))
print('         MJD  = %11.5f UT' % jd)
print()

std = input('INTERVAL ? ')
i = float(std)
jd += i

# ユリウス日から年月日を求め、再度ユリウス日を求める
yy, mm, dd = lib.jdate(jd, lib.T)
jd = lib.julian(yy, mm, dd) - 2400000.5

print()
print('  RETURN DATE = %4d %2d %7.5f UT' % (yy, mm, dd))
print('         MJD  = %11.5f UT' % jd)
print()
