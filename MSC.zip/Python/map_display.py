# 入力したデータの星座確認
from PIL import Image, ImageDraw, ImageFont
import tkinter as tk
import csv
import glob


def drawing_frame(map_color, fonts, draw):
    latitude = [
        [16, '+75'],
        [80, '+60'],
        [128, '+40'],
        [160, '+20'],
        [192, '0'],
        [224, '-20'],
        [256, '-40'],
        [304, '-60'],
        [368, '-75']
    ]

    # フレーム
    draw.rectangle((28, 0, 610, 384), outline=map_color, width=1)

    # 緯度
    for i in range(9):
        y = latitude[i][0]
        la = latitude[i][1]
        drawing_latitude(y, la, draw)

    # 経度
    for lg in range(74, 610, 48):
        draw.line((lg, 0, lg, 5), fill=map_color, width=1)
        draw.line((lg, 379, lg, 384), fill=map_color, width=1)
    draw.text((71, 362), '0', font=fonts, fill=map_color)
    draw.text((162, 362), '60', font=fonts, fill=map_color)
    draw.text((256, 362), '120', font=fonts, fill=map_color)
    draw.text((352, 362), '180', font=fonts, fill=map_color)
    draw.text((496, 362), '300', font=fonts, fill=map_color)
    draw.text((584, 362), '330', font=fonts, fill=map_color)


# 緯度を描く
def drawing_latitude(y, la, draw):
    draw.line((28, y, 33, y), fill=map_color, width=1)
    draw.line((605, y, 610, y), fill=map_color, width=1)
    if la == '0':
        draw.text((9, y - 9), la, font=fonts, fill=map_color)
        draw.text((622, y - 9), la, font=fonts, fill=map_color)
    else:
        draw.text((2, y - 9), la, font=fonts, fill=map_color)
        draw.text((614, y - 9), la, font=fonts, fill=map_color)


# 世界地図を描く
def drawing_map(map_color, draw):
    # 地図データの読み込み
    files = glob.glob('./map/*.csv')

    for file_name in files:
        fp = open(file_name, 'r')
        reader = csv.reader(fp)

        for data in reader:
            x = int(data[0]) * 4
            y = int(data[1]) * 4 + 18

            draw.rectangle((x - 2, y - 2, x + 2, y + 2), fill=map_color)

        fp.close()


root = tk.Tk()
root.resizable(False, False)
root.geometry('644x404')
root.title('マイコン宇宙講座 - 世界地図')

img = Image.new('RGB', (642, 402), (0, 0, 0))
draw = ImageDraw.Draw(img)

canvas = tk.Canvas(root, width=642, height=402, bg='black')
canvas.pack(anchor=tk.NW)

# フォント名は実行環境に合わせて変更すること
# TrueTypeの等幅フォント名を指定する
fonts = ImageFont.truetype('Ubuntu-L.ttf', 14)

# カラーパレット
map_color = (80, 160, 0)

# フレーム描画
drawing_frame(map_color, fonts, draw)

# 地図プロット
drawing_map(map_color, draw)

# 描画した星座の画像を保存
img.save('./images/map.png')

# 地図表示
photo = tk.PhotoImage(file='./images/map.png')
canvas.create_image(1, 1, image=photo, anchor=tk.NW)

root.mainloop()
