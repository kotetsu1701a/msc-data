# m61.py
# マイコン宇宙講座
# 6-1 彗星の位置予報プログラム
import math
import lib


M2PI = 2.0 * math.pi

x = [[0 for i in range(10)] for j in range(4)]
f = [0, 0, 0, 0]
q = [0, 0, 0, 0]
fx = [0, 0, 0, 0]   # f[n + 3]
qx = [0, 0, 0, 0]   # q[n + 3]
sx = [0, 0, 0, 0]   # s[n]
ex = [0, 0, 0, 0]   # e[n]
tx = [0, 0, 0, 0]
elm = [0 for i in range(11)]


# 彗星の軌道要素
# 他の彗星の場合は、ここのデータを入れ替える
# ただし、離心率が0.8を超える彗星のみ
def OrbitElements():
    elm = [0 for i in range(11)]

    c = 'COMET P/Halley'
    elm[1] = 1986.0         # 近日点通過時刻 T
    elm[2] = 2.0
    elm[3] = 9.6613
    elm[4] = 0.587096       # 近日点距離 q
    elm[5] = 0.967267       # 離心率 e
    elm[6] = 111.8534       # 近日点引数 ω
    elm[7] = 58.1531        # 昇交点黄経 Ω
    elm[8] = 162.2378       # 軌道傾斜角 i
    elm[9] = 5.2            # 全光度 m1
    elm[10] = 0.2           # 尾

    return c, elm


print()
std = input('計算を始めたい日と時分(JST) ? ')
dy, dt = std.split(',')
dy = float(dy)
dt = float(dt)

jd, yy, mm, dd, hh, ms, ss = lib.mjd(dy, dt)

jd = 10.0 * int(jd / 10.0)
jd1 = jd

std = input('計算期間(日単位) ? ')
ii = int(std)
std = input('計算間隔(日単位) ? ')
iv = int(std)

yz = 0
mz = 0

jd2 = jd + ii

# 彗星の位置予報

# 彗星の軌道要素の読み込み
c, elm = OrbitElements()
yy = elm[1]
mm = elm[2]
dd = elm[3]
pe = elm[6]
nd = elm[7]
ic = elm[8]
m1 = elm[9]
tl = elm[10]

jd = lib.julian(yy, mm, dd) - 2400000.5
t = jd

pe = pe / lib.K[3]
nd = nd / lib.K[3]
ic = ic / lib.K[3]

f, q = lib.eph_const(pe, nd, ic, lib.K)

for i in range(1, 4):
    fx[i] = f[i]
    qx[i] = q[i]

no = lib.K[1] / math.pow(elm[4] / (1.0 - elm[5]), 1.5)
a = elm[4] / (1.0 - elm[5])
pd = pow(a, 1.5)

print()
print('    ' + c)
print()
print('     T    =  %4d  %2d  %7.4f ET' % (yy, mm, dd))
print('     Peri.= %8.5f               e = %10.6f' % (pe * lib.K[3], elm[5]))
print('     Node = %9.5f (1950)        a = %9.5f AU' % (nd * lib.K[3], a))
print('     Inc. = %8.5f               n =  %9.6f' % (ic * lib.K[3], no * lib.K[3]))
print('        q =  %9.6f (AU)         P =  %4.2f 年' % (elm[4], pd))
print()
print('Date (0時ET)    R.A. (1950) Decl.     Delta      r      Mag    Elong.   PA   Tail')
print('----------------------------------------------------------------------------------')
print('   年  月  日    h  m        。 ,        AU       AU     等       。      。    。')

# 太陽座標(X,Y,Z)
while True:
    t1 = jd1 - 33281.92334
    t1 = t1 * (2.737909288e-5 + 1.260132857e-17 * t1)
    t2 = t1 * t1

    e, m, p, n, i, a, rd = lib.mean_elements(3, t1, t2)    # GOSUB 5300

    pe = p
    nd = n
    ic = i

    f, q = lib.eph_const(pe, nd, ic, lib.K)                 # GOSUB 4000

    ec = e
    mo = m / M2PI
    mo = M2PI * (mo - int(mo))
    ss, cc, ff = lib.kepler(mo, ec)                     # GOSUB 8500
    b = a * math.sqrt(1.0 - ec * ec)
    for n in range(1, 4):
        f[n] = a * f[n]
        q[n] = b * q[n]

    rs = 0
    for n in range(1, 4):
        x[n][3] = -(ff * f[n] + ss * q[n])
        rs = rs + math.pow(x[n][3], 2)
    rs = math.sqrt(rs)                                      # 地球と太陽との距離

    # 彗星の位置(赤経・赤緯)
    dl = 0
    while True:
        tp = jd1 - 0.005776 * dl
        ss, cc, v = lib.nearly_parabolic(tp, t, elm[4], elm[5], lib.K)

        rc = 0
        ds = 0
        for n in range(1, 4):
            sx[n] = fx[n] * cc + qx[n] * ss
            ex[n] = sx[n] + x[n][3]
            rc = rc + math.pow(sx[n], 2)
            ds = ds + math.pow(ex[n], 2)
        rc = math.sqrt(rc)                                  # 太陽と彗星の距離
        ds = math.sqrt(ds)                                  # 地球と彗星の距離
        if abs(ds - dl) > 0.001:
            dl = ds
        else:
            break

    ss = ex[2]
    cc = ex[1]
    tt = lib.quadrant(ss, cc)                               # GOSUB 3500
    ra = tt
    dc = math.atan(ex[3] * math.cos(ra) / ex[1])
    mg = m1 + 5.0 * math.log(ds) / 2.30259 + 15.0 * math.log(rc) / 2.30259

    cc = (rs * rs + ds * ds - rc * rc) / (2.0 * rs * ds)
    ss = math.sqrt(1.0 - cc * cc)
    eg = math.atan(ss / cc)
    if eg < 0:
        eg = eg + math.pi

    dl = 0
    for n in range(1, 4):
        tx[n] = fx[n] * (rc + tl) * math.cos(v) + qx[n] * (rc + tl) * math.sin(v)
        tx[n] = tx[n] + x[n][3]
        dl = dl + math.pow(tx[n], 2)

    ss = tx[2]
    cc = tx[1]
    tt = lib.quadrant(ss, cc)                               # GOSUB 3500

    rt = tt
    dt = math.atan(tx[3] * math.cos(rt) / tx[1])
    dl = math.sqrt(dl)

    cc = (math.pow(ds, 2) + math.pow(dl, 2) - math.pow(tl, 2)) / (2.0 * ds * dl)

    # (1.0 - cc * cc)の計算結果が０より小さい場合は見かけ上の尾の長さを０とする
    if (1.0 - cc * cc) < 0:
        cl = 0
    else:
        ss = math.sqrt(1.0 - cc * cc)
        cl = math.atan(ss / cc)

    ss = math.cos(dt) * math.sin(rt - ra)
    cc = math.cos(dc) * math.sin(dt) - math.sin(dc) * math.cos(dt) * math.cos(rt - ra)
    tt = lib.quadrant(ss, cc)                               # gosub 3500
    pa = tt

    # 位置予報
    jd = jd1
    yy, mm, dd = lib.jdate(jd, lib.T)

    ra = ra * lib.K[3] / 15.0
    dc = dc * lib.K[3]

    rh = int(ra)
    rm = 60.0 * (ra - rh)
    if int(rm + 1.0e-3) == 60:
        rh = rh + 1
        rm = 0

    sg = lib.sgn(dc)
    dc = abs(dc)
    dh = int(dc)
    dm = 60.0 * (dc - dh)
    if int(dm + 0.01) == 60:
        dc = dc + 1
        dm = 0

    str_sg = '+'
    if sg < 0:
        str_sg = '-'

    eg = eg * lib.K[3]
    cl = cl * lib.K[3]
    pa = pa * lib.K[3]

    sfmt = '         %2d    %2d %5.2f   %s%2d %4.1f   %6.3f   %6.3f   %4.1f    %5.1f   %5.1f  %4.1f' % (dd, rh, rm, str_sg, dh, dm, ds, rc, mg, eg, pa, cl)
    if yy != yz:
        sfmt = '%4d %2d  %2d    %2d %5.2f   %s%2d %4.1f   %6.3f   %6.3f   %4.1f    %5.1f   %5.1f  %4.1f' % (yy, mm, dd, rh, rm, str_sg, dh, dm, ds, rc, mg, eg, pa, cl)
    else:
        if mm != mz:
            sfmt = '     %2d  %2d    %2d %5.2f   %s%2d %4.1f   %6.3f   %6.3f   %4.1f    %5.1f   %5.1f  %4.1f' % (mm, dd, rh, rm, str_sg, dh, dm, ds, rc, mg, eg, pa, cl)
    print(sfmt)

    yz = yy
    mz = mm
    jd1 = jd1 + iv
    if jd1 < jd2:
        continue
    else:
        break
print('-----------------------------------------------------------------------------------')
print()
