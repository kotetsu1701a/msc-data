# m54.py
# マイコン宇宙講座
# 月の視位置計算プログラム
import math
import lib


M2PI = 2.0 * math.pi

lg = 139.745 / lib.K[3]
la = 35.654 / lib.K[3]
obs = 'Tokyo'

print()
std = input('DATE AND TIME(JST) ? ')
dy, dt = std.split(',')
dy = float(dy)
dt = float(dt)

jd, yy, mm, dd, hh, ms, ss = lib.mjd(dy, dt)

iv = input('INTERVAL(UNIT OF HOUR) ? ')
iv = float(iv)

ii = 0
yz = 0
mt = 0

print()
print('         Date (JST)     地心での月の位置      距離   %-7sでの月の位置   距離' % (obs))
print(' -------------------------------------------------------------------------------')
print('      年 月 日  時 分     h  m       。 ,       Km     h  m       。 ,       Km')

while ii < 32:
    t0 = (jd - 15019.5) / 36525.0

    a, b, c, d, e, g, j, l, m, n, v, w = lib.argument(t0)
    mx, my, mz = lib.moon(t0, a, b, d, e, n, g, w)

    r0 = c
    r1 = mx
    r2 = my
    r3 = mz

    ra, dc, dl = lib.positions(r0, r1, r2, r3)

    dl1 = dl
    if ra < 0:
        ra = ra + M2PI
    r1 = la

    r2 = lib.geocentric_distance(r1)

    r0 = r2 / 6378.16
    r1 = la
    r2 = 0

    r3 = lib.geocentric_latitude(r1, r2)

    fi = r3
    r1 = jd
    r2 = lg

    r3 = lib.siderealtime_date(r1, r2)

    s1 = r3
    x0 = r0 * math.cos(fi) * math.cos(s1)
    y0 = r0 * math.cos(fi) * math.sin(s1)
    z0 = r0 * math.sin(fi)

    xx = dl * math.cos(dc) * math.cos(ra)
    yy = dl * math.cos(dc) * math.sin(ra)
    zz = dl * math.sin(dc)

    x = xx - x0
    y = yy - y0
    z = zz - z0

    dl2 = math.sqrt(x * x + y * y + z * z)
    ss = y
    cc = x

    tt = lib.quadrant(ss, cc)

    mr = tt
    md = math.atan(z / (y / math.sin(mr)))

    # MJD to YY-MM-DD
    jd = jd + 0.375
    yy, mm, dd = lib.jdate(jd, lib.T)
    jd = jd - 0.375

    hh = 24.0 * (dd - int(dd))
    dd = int(dd)
    ms = 60.0 * (hh - int(hh))
    hh = int(hh)
    ms = int(ms + 0.1)
    if ms == 60:
        hh = hh + 1
        ms = 0

    # Print Position
    if ra < 0:
        ra = ra + M2PI
    if ra > M2PI:
        ra = ra - M2PI

    ra = ra * lib.K[3] / 15.0
    dc = dc * lib.K[3]
    dl1 = 6378.16 * dl1

    h1 = int(ra)
    m1 = 60.0 * (ra - h1)
    sg = lib.sgn(dc)
    dc = abs(dc)
    d1 = int(dc)
    f1 = 60.0 * (dc - d1)

    s1 = '+'
    if sg < 0:
        s1 = '-'

    mr = mr * lib.K[3] / 15.0
    md = md * lib.K[3]

    dl2 = 6378.16 * dl2
    h2 = int(mr)
    m2 = 60.0 * (mr - h2)
    sg = lib.sgn(md)
    md = abs(md)
    d2 = int(md)
    f2 = 60.0 * (md - d2)

    s2 = '+'
    if sg < 0:
        s2 = '-'

    sfmt = '          %2d  %2d %2d     %2d %5.2f  %s%2d %4.1f  %6d   %2d %5.2f  %s%2d %4.1f  %6d' % (dd, hh, ms, h1, m1, s1, d1, f1, dl1, h2, m2, s2, d2, f2, dl2)
    if yy != yz:
        sfmt = '  %4d %2d %2d  %2d %2d     %2d %5.2f  %s%2d %4.1f  %6d   %2d %5.2f  %s%2d %4.1f  %6d' % (yy, mm, dd, hh, ms, h1, m1, s1, d1, f1, dl1, h2, m2, s2, d2, f2, dl2)
    if mm != mt:
        sfmt = '       %2d %2d  %2d %2d     %2d %5.2f  %s%2d %4.1f  %6d   %2d %5.2f  %s%2d %4.1f  %6d' % (mm, dd, hh, ms, h1, m1, s1, d1, f1, dl1, h2, m2, s2, d2, f2, dl2)
    print(sfmt)

    yz = yy
    mt = mm
    ii = ii + 1
    if ii < 32:
        jd = jd + iv / 24.0

print(' -------------------------------------------------------------------------------')
print()
