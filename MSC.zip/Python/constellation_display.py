# 入力したデータの星座確認
from PIL import Image, ImageDraw, ImageFont
import tkinter as tk
import csv


def drawing_frame(frame_color, planet_color, fonts, draw):
    # フレームの描画
    # 星座
    draw.rectangle((156, 1, 640, 88), outline=frame_color, width=2)
    for ln in range(156, 520, 120):
        draw.line((ln, 1, ln, 88), fill=frame_color, width=2)
    draw.rectangle((156, 130, 640, 218), outline=frame_color, width=2)
    for ln in range(156, 520, 120):
        draw.line((ln, 130, ln, 218), fill=frame_color, width=2)
    draw.rectangle((156, 259, 640, 347), outline=frame_color, width=2)
    for ln in range(156, 520, 120):
        draw.line((ln, 259, ln, 347), fill=frame_color, width=2)

    # 説明文
    draw.rectangle((1, 1, 150, 347), outline=frame_color, width=2)
    draw.line((1, 130, 150, 130), fill=frame_color, width=2)
    draw.line((1, 180, 150, 180), fill=frame_color, width=2)
    draw.line((1, 304, 150, 304), fill=frame_color, width=2)

    # 日付・太陽と惑星の記号・タイトル
    draw.text((20, 147), "太陽と惑星の記号", font=fonts)
    draw.text((10, 190), "太陽 ---------(   )", font=fonts)
    draw.text((10, 208), "水星 ---------(   )", font=fonts)
    draw.text((10, 226), "金星 ---------(   )", font=fonts)
    draw.text((10, 244), "火星 ---------(   )", font=fonts)
    draw.text((10, 262), "木星 ---------(   )", font=fonts)
    draw.text((10, 280), "土星 ---------(   )", font=fonts)
    draw.text((27, 317), "マイコン星占い", font=fonts)

    # 太陽
    drawing_planet_symbol(0, 125, 197, planet_color[0], draw)
    # 水星
    drawing_planet_symbol(1, 125, 215, planet_color[1], draw)
    # 金星
    drawing_planet_symbol(2, 125, 233, planet_color[2], draw)
    # 火星
    drawing_planet_symbol(4, 125, 251, planet_color[4], draw)
    # 木星
    drawing_planet_symbol(5, 125, 269, planet_color[5], draw)
    # 土星
    drawing_planet_symbol(6, 125, 287, planet_color[6], draw)

    # 星座名の表示
    draw.text((180, 95), "みずがめ座", font=fonts)
    draw.text((315, 95), "やぎ座", font=fonts)
    draw.text((435, 95), "いて座", font=fonts)
    draw.text((550, 95), "さそり座", font=fonts)
    draw.text((180, 225), "てんびん座", font=fonts)
    draw.text((310, 225), "おとめ座", font=fonts)
    draw.text((435, 225), "しし座", font=fonts)
    draw.text((555, 225), "かに座", font=fonts)
    draw.text((187, 354), "ふたご座", font=fonts)
    draw.text((310, 354), "おうし座", font=fonts)
    draw.text((424, 354), "おひつじ座", font=fonts)
    draw.text((555, 354), "うお座", font=fonts)

    draw.text((5, 365), "Ok", font=fonts)
    draw.rectangle((5, 380, 14, 395), fill=(255, 255, 255))


def drawing_constellation(seiza_color, draw):
    # csv形式の星座データファイル名
    seiza_file = [
        "aquarius.csv",
        "capricorn.csv",
        "sagittarius.csv",
        "scorpio.csv",
        "libra.csv",
        "virgo.csv",
        "leo.csv",
        "cancer.csv",
        "gemini.csv",
        "taurus.csv",
        "aries.csv",
        "pisces.csv"
    ]

    # 星座データの読み込み
    for file_name in seiza_file:
        fp = open('./seiza/' + file_name, 'r')
        reader = csv.reader(fp)

        for data in reader:
            x = int(data[0]) * 4 + 154
            y = int(data[1]) * 4

            draw.rectangle((x - 2, y - 2, x + 2, y + 2), fill=seiza_color)

        fp.close()

    # 描画した星座の画像を保存
    img.save("./images/seiza.png")


# 惑星のシンボルを描く
def drawing_planet_symbol(p, x, y, color, draw):
    draw.ellipse((x - 5, y - 5, x + 5, y + 5), fill=color)
    if p == 6:
        draw.line((x - 10, y, x + 10, y), fill=color)


root = tk.Tk()
root.resizable(False, False)
root.geometry("644x404")
root.title("マイコン宇宙講座 - 星占いプログラム")

img = Image.new("RGB", (642, 402), (0, 0, 0))
draw = ImageDraw.Draw(img)

canvas = tk.Canvas(root, width=642, height=402, bg="black")
canvas.pack(anchor=tk.NW)

# フォント名は実行環境に合わせて変更すること
# TrueTypeの等幅フォント名を指定する
fonts = ImageFont.truetype("TakaoGothic.ttf", 14)

# カラーパレット
seiza_color = (255, 255, 255)
frame_color = (255, 255, 255)
planet_color = [
    "#ff0000",
    "#FFD7A0",
    "#FAAF3C",
    "#37AAE1",
    "#FF5050",
    "#B9BEB4",
    "#C8A05F",
    "#A0C8FA",
    "#3232E1",
    "#E6B96E"
]

# フレーム描画
drawing_frame(frame_color, planet_color, fonts, draw)

# 黄道12星座プロット
drawing_constellation(seiza_color, draw)

# 星座表示
photo = tk.PhotoImage(file="./images/seiza.png")
canvas.create_image(1, 1, image=photo, anchor=tk.NW)

root.mainloop()
